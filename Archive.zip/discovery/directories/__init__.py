# discovery/directories package
