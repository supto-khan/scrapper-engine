# Bounce detection module
